package P1C;

public class Name
{
	private String first; // First name
	private String last;  // Last name

	public Name()
	{
            this( "", "");
	} 

	public Name(String firstName, String lastName)
	{
            first = firstName;
            last = lastName;
	}

	public void setName(String firstName, String lastName)
	{
            setFirst(firstName);
            setLast(lastName);
	}

	public String getName()
	{
            return toString();
	}

	public void setFirst(String firstName)
	{
            first = firstName;
	}

	public String getFirst()
	{
            return first;
	} 

	public void setLast(String lastName)
	{
            last = lastName;
	}

	public String getLast()
	{
            return last;
	}

	public void giveLastNameTo(Name aName)
	{
            aName.setLast(last);
	}

	public String toString()
	{
            return first + " " + last;
	} 
} 
