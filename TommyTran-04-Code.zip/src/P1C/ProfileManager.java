package P1C;

/**
 * A profile manager on a simple social network.
 */

public class ProfileManager {

    private final AList<Profile> allProfiles;

    /**
     * DO NOT CHANGE
     * Constructor for an instance of a profile manager.
     */
    public ProfileManager() {
        /**
         * DO NOT CHANGE
         */
        allProfiles = new AList<>();
    }

    /**
     * Adds a profile onto the social network.
     */
    public void addProfile(Profile p) {
        allProfiles.add(p);
    } 

    /**
     * Removes a profile from the social network.
     */
    
    public void removeProfile(Profile p) {
        for (int x = 1; x <= allProfiles.getLength(); x++){
           while(allProfiles.getEntry(x) == p){ 
           allProfiles.remove(x);
           }
           allProfiles.getEntry(x).removeFriend(p);
       }// end for loop
        
    }

    /**
     * Created a friendship between two profiles on the social network.
     */
    public void createFriendship(Profile a, Profile b) {
        
        a.addFriend(b);
        b.addFriend(a);
        
    }

    /**
     * Ends a friendship between two profiles on the social network.
     */
    public void endFriendship(Profile a, Profile b) {
        
        a.removeFriend(b);
        b.removeFriend(a);
        
    } 

    /**
     * Displays each profile's information and friends.
     */
    public void display() {
        for (int x = 1; x <= allProfiles.getLength(); x++){
           allProfiles.getEntry(x).display();
           System.out.println();
       }// end for loop
    } 
}
