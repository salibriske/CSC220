package P1C;

import java.awt.image.*;

/**
 * A profile on a simple social network.
 */
public class Profile {

    private BufferedImage profilePicture;
    private Name profileName;
    private String status;
    private AList<Profile> friends;

    /** 
     * DO NOT CHANGE
     * Constructor for an instance of a profile.
     */
    public Profile() {
        /** 
         * DO NOT CHANGE
         * Constructor for an instance of a profile.
         */
        profilePicture = new BufferedImage(150, 150, BufferedImage.TYPE_INT_RGB);
        profileName = new Name("", "");
        status = "";
        friends = new AList<>();
    }

    public BufferedImage getProfilePicture() {
        return profilePicture;
    } 

    public void setProfilePicture(BufferedImage newPicture) {
        profilePicture = newPicture;
    }

    public Name getName() {
        return profileName;
    }

    /**
     * Sets the name associated with the profile 
     * to the given first and last name.
     */
    public void setName(String first, String last) {
        profileName = new Name (first, last);
    } 

    /**
     * Sets the name associated with the profile 
     * to the given name.
     */
    public void setName(Name name) {
        this.profileName = name;
    }

    /**
     * Sets the current status of the profile 
     * to the given string.
     */
    public void setStatus(String stat) {
        this.status = stat;
    }

    /**
     * Returns the status associated with the profile.
     */
    public String getStatus() {
        return status;
        //return toString();
    } 

    /**
     * Returns a list of all the profile's friends 
     */
    public AList<Profile> getFriends() {
        return friends;
    } 

    /**
     * Adds a friend to the profile's list of friends.
     */
    public void addFriend(Profile p) {
        if(!friends.contains(p)){
            friends.add(p);
        }
    } 

    /**
     * Removes a friend from the profile's list of friends.
     */
    public void removeFriend(Profile p) {
        for(int i = 1; i<=friends.getLength();i++){
            while(friends.contains(p)){
                friends.remove(i);
            }
        }
        //friends.remove(p);
    } 

    public String toString() {
        return "Name: " + getName() + "\n\tStatus: " + getStatus() + "\n\tPicture: " + getProfilePicture().toString().substring(0, 20) + "\n\t# of friends: " + friends.getLength() + "\n";
    }

    /**
     * Displays the profile's information and friends.
     */
    public void display() {
        System.out.print(toString());
        System.out.println("Friends:");
        for (int x = 1; x <= friends.getLength(); x++)
            System.out.println("\t" + friends.getEntry(x).getName());
    } 
} // end Profile
