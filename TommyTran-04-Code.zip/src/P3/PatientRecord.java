package P3;

public class PatientRecord {

    private int id;
    private String date;
    private String reasonForVisit;
    private String treatmentPrescribed;
    private int month;
    private int day;
    private int year;

    public PatientRecord(int anId, int month, int day, int year, String reason, String treatment){
        StringBuilder sb = new StringBuilder();
        id = anId;
        date = sb.append(month).append("/").append(day).append("/").append(year).toString();
        this.month = month; 
        this.day = day;
        this.year = year;
        reasonForVisit = reason;
        treatmentPrescribed = treatment;  
    }    
    
    public int getMonth(){
        return month;
    }
    
    public int getDay(){
        return day;
    }
    
    public int getYear(){
        return year;
    }

    /**
     * Returns the patient's ID number.
     */
    public int getPatientID() {
        return id;
    } 

    /**
     * Returns the patient's visit date.
     */
    public String getVisitDate() {
        return date;
    } 

    /**
     * Returns the patient's reason for visiting.
     */
    public String getReasonForVisit() {
        return reasonForVisit;
    } 

    /**
     * Returns the patient's prescribed treatment.
     */
    public String getTreatmentPrescribed() {
        return treatmentPrescribed;
    } 

    
    @Override
    public int hashCode() {
       int value = id * date.hashCode();
       if(value < 0){
           value = value + Integer.MAX_VALUE;
       }
        return value;
    } 

    @Override
    public boolean equals(Object other) {
        if(this == other){
        return true;
        }
        if(other == null){
        return false;
        }
        if(getClass() != other.getClass()){
        return false;
        }
        PatientRecord object = (PatientRecord) other;
        if(date == null) {
            if(object.date != null){
                return false;
            }else if (!date.equals(object.date))
                return false;
        }    
        if (id != object.id){
        return false;
        }
        if(reasonForVisit == null) {
            if(object.reasonForVisit != null){
                return false; 
            }else if(!reasonForVisit.equals(object.reasonForVisit)){
            return false;
            }
        if (treatmentPrescribed == null) {
            if(object.treatmentPrescribed != null)
                return false;
            }else if(!treatmentPrescribed.equals(object.treatmentPrescribed)){
                return false;  
            }
        }
        return true;
    } 

    @Override
    public String toString() {
        return " PatientRecords: " + id + " " + date 
                + " Complaint: " + reasonForVisit + " Prescribed: " 
                + treatmentPrescribed;
    } 

} 
