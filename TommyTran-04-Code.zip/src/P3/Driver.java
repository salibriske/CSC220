package P3;

/**
 * 
 * DO NOT CHANGE
 *
 * A driver for the class PatientRecord.
 */
public class Driver {

    public static void main(String args[]) {
        PatientRecord test1;
        PatientRecord test2;

        try {
            test1 = new PatientRecord(101, 12, 15, 2006, "cough", "bed rest");
            if(test1.getMonth() < 1 || test1.getMonth() > 12){
                throw new BadVisitDateException("Month not in range 1-12");
            }else if(test1.getDay() < 1  || test1.getDay() > 31){
                throw new BadVisitDateException("Day not in range 1-31");
            }else if(test1.getYear() < 1900){
                throw new BadVisitDateException("Year not greater than 1900");
            }
            System.out.println("Patient Record created:  " + test1);
            System.out.println("It has hash code " + test1.hashCode());
        }
        catch (BadVisitDateException e) {
            System.out.println("Creation failed " + e);
        } 

        try {
            test2 = new PatientRecord(101, 12, 17, 2006, "high fever", "antibiotics");
            if(test2.getMonth() < 1 || test2.getMonth() > 12){
                throw new BadVisitDateException("Month not in range 1-12");
            }else if(test2.getDay() < 1 || test2.getDay() > 31){
                throw new BadVisitDateException("Day not in range 1-31");
            }else if(test2.getYear() < 1900){
                throw new BadVisitDateException("Year not greater than 1900");
            }
            System.out.println("Patient Record created:  " + test2);
            System.out.println("It has hash code " + test2.hashCode());
        } 
        catch (BadVisitDateException e) {
            System.out.println("Creation failed " + e);
        }

        try {
            test2 = new PatientRecord(101, 17, 17, 2006, "high fever", "antibiotics");
            if(test2.getMonth() < 1 || test2.getMonth() > 12){
                throw new BadVisitDateException("Month not in range 1-12");
            }else if(test2.getDay() < 1 || test2.getDay() > 31){
                throw new BadVisitDateException("Day not in range 1-31");
            }else if(test2.getYear() < 1900){
                throw new BadVisitDateException("Year not greater than 1900");
            }
            System.out.println("Patient Record created:  " + test2);
            System.out.println("It has hash code " + test2.hashCode());
        } 
        catch (BadVisitDateException e) {
            System.out.println("Creation failed " + e);
        }

        try {
            test2 = new PatientRecord(101, 12, 92, 2006, "high fever", "antibiotics");
            if(test2.getMonth() < 1 || test2.getMonth() > 12){
                throw new BadVisitDateException("Month not in range 1-12");
            }else if(test2.getDay() < 1 || test2.getDay() > 31){
                throw new BadVisitDateException("Day not in range 1-31");
            }else if(test2.getYear() < 1900){
                throw new BadVisitDateException("Year not greater than 1900");
            }         
            System.out.println("Patient Record created:  " + test2);
            System.out.println("It has hash code " + test2.hashCode());
        }
        catch (BadVisitDateException e) {
            System.out.println("Creation failed " + e);
        } 

        try {
            test2 = new PatientRecord(101, 12, 17, 06, "high fever", "antibiotics");
            if(test2.getMonth() < 1 || test2.getMonth() > 12){
                throw new BadVisitDateException("Month not in range 1-12");
            }else if(test2.getDay() < 1 || test2.getDay() > 31){
                throw new BadVisitDateException("Day not in range 1-31");
            }else if(test2.getYear() < 1900){
                throw new BadVisitDateException("Year not greater than 1900");
            }
            System.out.println("Patient Record created:  " + test2);
            System.out.println("It has hash code " + test2.hashCode());
        }
        catch (BadVisitDateException e) {
            System.out.println("Creation failed " + e);
        } 
    } 
}
