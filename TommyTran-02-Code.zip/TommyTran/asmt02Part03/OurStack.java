package asmt02Part03;

import java.util.Stack;
/**
   A class of stacks.

    * @author Tommy Tran
    * @author Kevin Rockwell
    * @date 2017-09-26
    * @course CSC 220-3 "Data Structure"
    * @assignment 3
 */
public class OurStack<T> implements StackInterface<T>
{
	Stack<T> theStack;

	public OurStack() { 
            theStack = new Stack();
        } // end default constructor

        @Override
	public void push(T newEntry) { 
            theStack.push(newEntry);
        } // end push
         
        @Override
	public T peek() {
            return theStack.peek();
        } // end peek

        @Override
	public T pop() { 
            return theStack.pop();
        } // end pop

        @Override
	public boolean isEmpty() {
            return theStack.isEmpty();
        } //end isEmpty

        @Override
	public void clear() { 
            theStack.clear();
        } // end clear
     
        } // end OurStack
