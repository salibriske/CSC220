package asmt02Part03;

import java.util.Scanner;
/**
   A class that determines whether or not a string is a palindrome;
   that is, a string that's able to be spelled the same way from
   left to right as it is right to left, ignoring punctuation,
   spaces, and case.
   
    * @author Tommy Tran
    * @author Kevin Rockwell
    * @date 2017-09-26
    * @course CSC 220-3 "Data Structure"
    * @assignment 3
  
   @version 4.0
 */
public class PalindromeChecker 
{
	/** 
	 *
	 * Tests whether a string is a palidrome, ignoring punctuation, spaces, and case. 
	 * @param aString  A string.
         * @return
	 *
	 * */
	public static boolean isPalindrome(String aString)
	{
		StringBuilder tempString = new StringBuilder(aString);
                OurStack theStack = new OurStack();
                boolean result = true;
                boolean done = false;
                int numChars = 0;
                int continuingIndex = 0;
                aString = aString.toLowerCase();
                String compareString = "";
                
                //push in stack string to comapre characters
                for(int i = 0; i < aString.length(); i++){
                    if(!Character.isSpaceChar(aString.charAt(i)) && !isPunctuation(aString.charAt(i))){
                    compareString += aString.charAt(i);
                    theStack.push(aString.charAt(i));
                    numChars++;
                    }// end if
                }// end for
                
                //Run stack and push elements to compareString
		while (!done && (continuingIndex < numChars)){
			// Check whether the character at the top of the stack
			// is equal to the character at the current position in tempString.
                        
                    if((char)theStack.pop() != compareString.charAt(continuingIndex)){
                        return false;
                    }//end if 
                     continuingIndex++;   
		} // end while

		return result;
	} // end isPalindrome

	/** Tests whether a character is a punctuation mark, such as a period.
	 *
	 * @param aCharacter  The character to be tested.
	 * @return  True if the character is a punctuation mark, or false if not. 
	 *
	 */
	public static boolean isPunctuation(char aCharacter)
	{   
            
            //punctations to contains !, ?, \, , ., :," to make palindrome work. 
             if (aCharacter == '!' | aCharacter == '?' | aCharacter == ',' | aCharacter == '.' | aCharacter == ':' | aCharacter == '\''| aCharacter == ';' | aCharacter == '"') {
                
                return true;
                } else {
                return false;
             }//end if 
        
	} // end isPunctuation

	public static void main(String[] args)
	{
		Scanner keyboard = new Scanner(System.in);
                boolean keepGoing = true;
                while(keepGoing){
                    System.out.print("Enter a string that you want to check (or enter ! to exit): ");
                    String input = keyboard.nextLine();
                    if(input.equals("!")){
                        keepGoing = false;
                    }
                    if(isPalindrome(input)){
                        System.out.println(input + " IS a palindrome!");
                    }else{
                        System.out.println(input + " is Not a palindrome!");
                    }
                }
		//
		System.out.println("Done!");
	} // end main
} // end PalindromeChecker
