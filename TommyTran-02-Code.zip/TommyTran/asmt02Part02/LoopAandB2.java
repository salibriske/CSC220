/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package asmt02Part02;

/**
 * @author Tommy Tran
 * @author Kevin Rockwell
 * @date @date 2017-09-20
 * @course CSC 220-3 "Data Structure"
 * @assignment 2.2.3 loop a and b
 */
public class LoopAandB2 {
    
    public static void A(int n){
        int sum = 0;
        int i;
        int j;
        for(i = 1; i <= n; i++){
            for (j = 1; j<= 10000; j++){
                sum = sum + j;
                
            }
        }
    }
    
    public static void B(int n){
        int sum = 0;
        int i;
        int j;
        int k;
        for(i = 1; i <= n; i++){
            for (j = 1; j<= n; j++){
                for(k = 1; k<= n; k++){
                
                    sum = sum + k;
                }
            }
        }
    }
    
    //run A and B with increasing n until the running time for B exceeds the running time for A.
    //nanotime calculates time in nano seconds and each time is different in the output
    public static void main(String [] args){
        int n = 1;
        long timeA = 0, timeB = 0;
        
        do{
            timeA = System.nanoTime();
            A(n);
            timeA = System.nanoTime() - timeA;
            
            timeB = System.nanoTime();
            B(n);
            timeB = System.nanoTime() - timeB;
            
            n++;
      
        }while(timeB > timeA);
        
        System.out.println("n = " + n);
        System.out.println("time for A " + timeA);
        System.out.println("time for B " + timeB);
    }
    
}

