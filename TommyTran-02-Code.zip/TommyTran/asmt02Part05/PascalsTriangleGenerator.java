package asmt02Part05;

/**
 *
 * @author JavaF
 */
public class PascalsTriangleGenerator {

    private int[] row1, row2;

    /**
     * Creates the initial two rows of Pascal's triangle.
     */
    public PascalsTriangleGenerator() {
        int [] row1 = {1};
        int [] row2 = {1,1};
        
        
    }
    

    /**
     * Recursively computes the specified row of Pascal's Triangle.
     */
    public int[] computeRow(int rowToCompute) { 
        /*if(rowToCompute == 1) {
            int[] arr1 = new int[1];   
            arr1[0] = 1;
            return arr1;
        }else{
            int[] lastRow = computeRow(rowToCompute - 1);
            int[] thisRow = computeNextRow(lastRow);
        return thisRow;
        }*/
        int x = 0;
        if(x == rowToCompute){
            
        }
        return computeRow(rowToCompute);
    }    
    /**
     * Computes the next row of Pascal's Triangle given the previous one.
     */
    public int[] computeNextRow(int[] previousRow) {
        int[] newAr = new int[previousRow.length + 1];
        newAr[0] = 1;
        newAr[previousRow.length] = 1;

        for(int i = 1; i < previousRow.length; i++){
            newAr[i] = previousRow[i-1] + previousRow[i];
        }

        return newAr;

    }
}
