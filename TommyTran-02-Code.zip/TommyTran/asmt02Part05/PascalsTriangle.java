package asmt02Part05;

import java.util.Scanner;

/**
 * @author JavaF
 */
public class PascalsTriangle {

    /**
     * Generates and prints the row of Pascal's Triangle requested by the user.
     */
    public static void main(String args[]) {
        //
        PascalsTriangleGenerator row = new PascalsTriangleGenerator();
	Scanner scan = new Scanner(System.in);
        
        
        //
        
        System.out.println("Which line number of Pascal's Triangle? ");
        int rowNumber = scan.nextInt();
        System.out.println(row.computeRow(rowNumber));
        
        
	String another="";
        while (another.equalsIgnoreCase("y")) {
            System.out.print("another (y/n) ");
            another = scan.next();
           
        }
        
    }
}
