package asmt02Part04;

/**
 * @author Tommy Tran
 * @author Kevin Rockwell
 * @date @date 2017-09-24
 * @course CSC 220-3 "Data Structure"
 * @assignment 2.3
 */
import java.util.Scanner;

public class Blurbs {

    /**
     * Generates a series of Blurbs (a word in an alien language).
     *
     * @param args
     */
    public static void main(String args[]) {
        BlurbGenerator blurbMaker = new BlurbGenerator();
        Scanner scan = new Scanner(System.in);

        System.out.println("How many blurbs would you like? ");
        int numBlurbs = scan.nextInt();

        for (int i = 1; i <= numBlurbs; i++) {
            System.out.println("Blurb #" + i + ": " + blurbMaker.makeBlurb());
        }
    }
}
