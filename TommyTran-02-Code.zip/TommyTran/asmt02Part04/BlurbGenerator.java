package asmt02Part04;

import java.util.Random;

/**
 * @author Tommy Tran
 * @author Kevin Rockwell
 * @date @date 2017-09-24
 * @course CSC 220-3 "Data Structure"
 * @assignment 2.3
 */
public class BlurbGenerator {

    private final Random gen;

    /**
     * Instantiates a random number generator needed for blurb creation.
     */
    public BlurbGenerator() { 
        gen = new Random();
    }

    /**
     * Generates and returns a random Blurb. A Blurb is a Whoozit followed by
     * one or more Whatzits.
     * @return 
     */
    public String makeBlurb() { 
        StringBuilder blurb = new StringBuilder();
        blurb.append(makeWhoozit());
        blurb.append(makeMultiWhatzits());
        
        return blurb.toString();
    }

    /**
     * Generates a random Whoozit. A Whoozit is the character 'x' followed by
     * zero or more 'y's.
     */
    private String makeWhoozit() { 
        StringBuilder whoozit = new StringBuilder();
        whoozit.append("x");
        whoozit.append(makeYString());
        
        return whoozit.toString();
    } 
    /**
     * Recursively generates a string of zero or more 'y's.
     */
    private String makeYString() { 
        StringBuilder y = new StringBuilder();
        boolean stop = gen.nextBoolean();
        if(!stop){
            y.append(makeYString());
        }else{
            return y.toString();
        }
        y.append("y");
        return y.toString();
    }

    /**
     * Recursively generates a string of one or more Whatzits.
     */
    private String makeMultiWhatzits() { 
        StringBuilder whatzits = new StringBuilder();
        whatzits.append(makeWhatzit());
        boolean stop = gen.nextBoolean();
        if(!stop){
            whatzits.append(makeMultiWhatzits());
        }else{
            return whatzits.toString();
        }
            return whatzits.toString();
    }

    /**
     * Generates a random Whatzit. A Whatzit is a 'q' followed by either a 'z'
     * or a 'd', followed by a Whoozit.
     */
    private String makeWhatzit() { 
        StringBuilder whatzit = new StringBuilder();
        whatzit.append("q");
        boolean string = gen.nextBoolean();
        if(string){
            whatzit.append("z");
        }else{
            whatzit.append("d");
        }
        whatzit.append(makeWhoozit());
        return whatzit.toString();
    }
}
